<template>
  <div class="bottomDiv" ><img src="../../assets/bottom.png" alt=""></div>
</template>

<script>
export default {};
</script>

<style scoped>
.bottomDiv
{
    width: 100%;
    padding-top: 0.625rem;
}
img
{
    width: 100%;
}
</style>